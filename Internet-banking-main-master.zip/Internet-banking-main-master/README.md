# Node.js prototype with Internet Banking
Fully working website with user Login and SignUp :

## Database:
MONGODB ->> NOSQL database
connecting to server by mongoose

## Front-End
HTML, CSS, JAVASCRIPT, JQUERY, BOOTSTRAP

## Back-End
NODE JS -->> EXPRESS JS FRAMEWORK USED

### HOW TO USE

### Prequisites
NODE JS, NPM, INTERNET

Download all the files and just start the main server file with command:
## mongod
## node app.js

"both commands in different terminals, run it as root if error occurs"

Its not a authenticated framework. you.ll need passport framework of node to use security and authentication 
