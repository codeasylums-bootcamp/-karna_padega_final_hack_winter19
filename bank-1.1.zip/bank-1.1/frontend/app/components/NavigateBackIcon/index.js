import NavigateBefore from '@material-ui/icons/NavigateBefore';
import styled from 'styled-components';

const NavigateBackIcon = styled(NavigateBefore)`
  margin-top: -1.7px;
`;

export default NavigateBackIcon;
