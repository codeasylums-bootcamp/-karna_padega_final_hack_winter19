import styled from 'styled-components';

const Icon = styled.img`
  width: auto;
  height: 42px;
`;

export default Icon;
