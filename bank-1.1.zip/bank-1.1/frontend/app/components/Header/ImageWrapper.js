import styled from 'styled-components';

const ImageWrapper = styled.div`
  margin: 0 10px;
`;

export default ImageWrapper;
