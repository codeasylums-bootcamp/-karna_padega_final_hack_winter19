/**
 *
 * AvailableFundsWrapper
 *
 */

import styled from 'styled-components';

const AvailableFundsWrapper = styled.span`
  font-weight: 700;
`;

export default AvailableFundsWrapper;
