/**
 *
 * AmountWrapper
 *
 */

import styled from 'styled-components';

const AmountWrapper = styled.span`
  font-weight: 700;
`;

export default AmountWrapper;
