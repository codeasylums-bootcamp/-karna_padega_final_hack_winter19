/**
 *
 * AuthorizationKeyContainer
 *
 */

import styled from 'styled-components';

const AuthorizationKeyContainer = styled.div`
  padding-bottom: 10px;
`;

export default AuthorizationKeyContainer;
