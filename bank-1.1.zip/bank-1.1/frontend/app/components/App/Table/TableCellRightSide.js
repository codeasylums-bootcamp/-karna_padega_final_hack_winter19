/**
 *
 * TableCellRightSide
 *
 */

import styled from 'styled-components';

const TableCellRightSide = styled.span`
  float: right;
`;

export default TableCellRightSide;
