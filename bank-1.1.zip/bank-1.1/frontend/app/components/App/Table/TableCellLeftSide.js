/**
 *
 * TableCellLeftSide
 *
 */

import styled from 'styled-components';

const TableCellLeftSide = styled.span`
  float: left;
`;

export default TableCellLeftSide;
