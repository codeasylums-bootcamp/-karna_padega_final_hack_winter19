/**
 *
 * TextWrapper
 *
 */

import styled from 'styled-components';

const TextWrapper = styled.span`
  font-size: 0.875em;
`;

export default TextWrapper;
