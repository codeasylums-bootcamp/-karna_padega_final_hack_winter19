/**
 *
 * LoadingWrapper
 *
 */

import styled from 'styled-components';

const LoadingWrapper = styled.div`
  display: flex;
  height: 193.24px;
`;

export default LoadingWrapper;
