/**
 *
 * LoadingLinear
 *
 */

import React from 'react';
import LoadingWrapper from './LoadingWrapper';

export default function LoadingLinear() {
  return <LoadingWrapper />;
}
