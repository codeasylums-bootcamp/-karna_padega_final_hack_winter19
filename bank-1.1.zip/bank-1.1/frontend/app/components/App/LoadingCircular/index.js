/**
 *
 * LoadingCircular
 *
 */

import React from 'react';
import LoadingWrapper from './LoadingWrapper';

export default function LoadingCircular() {
  return <LoadingWrapper />;
}
