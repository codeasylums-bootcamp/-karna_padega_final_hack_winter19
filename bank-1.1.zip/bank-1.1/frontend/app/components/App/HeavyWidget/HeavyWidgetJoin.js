/**
 *
 * HeavyWidgetJoinText
 *
 */

import styled from 'styled-components';

const HeavyWidgetJoin = styled.div`
  display: flex;
  align-items: baseline;
`;

export default HeavyWidgetJoin;
