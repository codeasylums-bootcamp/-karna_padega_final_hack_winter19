/**
 *
 * HeavyWidgetMain
 *
 */

import styled from 'styled-components';

const HeavyWidgetMain = styled.main`
  font-size: 1.375em;
`;

export default HeavyWidgetMain;
