/**
 *
 * HeavyWidgetUnit
 *
 */

import styled from 'styled-components';

const HeavyWidgetUnit = styled.span`
  margin-left: 0.3125em;
`;

export default HeavyWidgetUnit;
