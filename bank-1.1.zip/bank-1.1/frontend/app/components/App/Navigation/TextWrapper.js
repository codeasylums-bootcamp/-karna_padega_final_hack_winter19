/**
 *
 * Textwrapper
 *
 */

import styled from 'styled-components';

const Textwrapper = styled.span`
  margin-left: 20px;
`;

export default Textwrapper;
