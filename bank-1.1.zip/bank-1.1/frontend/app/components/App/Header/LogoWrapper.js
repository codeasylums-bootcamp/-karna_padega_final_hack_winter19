/**
 *
 * LogoWrapper
 *
 */

import styled from 'styled-components';

const LogoWrapper = styled.img`
  width: 2.5em;
  margin: 0 0.375em;
`;

export default LogoWrapper;
