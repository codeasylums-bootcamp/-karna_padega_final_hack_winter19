/**
 *
 * ItemDetailWrapper
 *
 */

import styled from 'styled-components';

const ItemDetailWrapper = styled.div`
  padding: 4px 0;
`;

export default ItemDetailWrapper;
