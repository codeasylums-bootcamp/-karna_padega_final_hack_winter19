/**
 *
 * MainDetailWrapper
 *
 */

import styled from 'styled-components';

const MainDetailWrapper = styled.div`
  font-size: 14.5px;
  font-family: 'Lato';
`;

export default MainDetailWrapper;
