/**
 *
 * DetailContainerWrapper
 *
 */

import styled from 'styled-components';

const DetailContainerWrapper = styled.div`
  padding: 5px 34px;
  line-height: 1.25;
`;

export default DetailContainerWrapper;
