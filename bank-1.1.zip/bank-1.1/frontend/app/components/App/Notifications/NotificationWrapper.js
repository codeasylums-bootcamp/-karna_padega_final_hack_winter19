/**
 *
 * NotificationWrapper
 *
 */

import styled from 'styled-components';

const NotificationWrapper = styled.div`
  max-height: 119px;
  overflow: auto;
`;

export default NotificationWrapper;
