/**
 *
 * TextWrapper
 *
 */

import styled from 'styled-components';

const TextWrapper = styled.span`
  opacity: 0.3;
`;

export default TextWrapper;
