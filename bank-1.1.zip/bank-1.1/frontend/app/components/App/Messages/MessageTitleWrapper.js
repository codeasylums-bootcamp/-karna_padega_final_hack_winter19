/**
 *
 * MessageTitleWrapper
 *
 */

import styled from 'styled-components';

const MessageTitleWrapper = styled.div`
  margin-top: 4.5px;
`;

export default MessageTitleWrapper;
