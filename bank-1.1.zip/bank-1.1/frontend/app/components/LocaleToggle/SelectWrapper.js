import styled from 'styled-components';

const SelectWrapper = styled.div`
  width: 70px;
  position: relative;
`;

export default SelectWrapper;
