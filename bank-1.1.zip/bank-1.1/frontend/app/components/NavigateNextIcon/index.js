import NavigateNext from '@material-ui/icons/NavigateNext';
import styled from 'styled-components';

const NavigateNextIcon = styled(NavigateNext)`
  margin-top: -1.7px;
`;

export default NavigateNextIcon;
