import styled from 'styled-components';

const LocaleToggleWrapper = styled.div`
  margin: 10px;
`;

export default LocaleToggleWrapper;
