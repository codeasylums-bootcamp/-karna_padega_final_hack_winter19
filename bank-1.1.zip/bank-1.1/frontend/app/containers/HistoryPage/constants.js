/*
 *
 * HistoryPage constants
 *
 */

export const GET_GRID_DATA = 'app/HistoryPage/GET_GRID_DATA';
export const GET_GRID_DATA_SUCCESS = 'app/HistoryPage/GET_GRID_DATA_SUCCESS';
export const GET_GRID_DATA_ERROR = 'app/HistoryPage/GET_GRID_DATA_ERROR';

export const CHANGE_PAGE = 'app/HistoryPage/CHANGE_PAGE';
export const TOGGLE_ROW_DETAIL = 'app/HistoryPage/TOGGLE_ROW_DETAIL';
