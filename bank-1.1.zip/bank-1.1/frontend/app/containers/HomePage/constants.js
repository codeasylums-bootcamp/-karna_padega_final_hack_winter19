/*
 *
 * HomePage constants
 *
 */

export const IS_LOGGED = 'app/HomePage/IS_LOGGED';
